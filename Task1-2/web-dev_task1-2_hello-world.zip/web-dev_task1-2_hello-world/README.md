## web开发::任务1-2::第一个web应用-Hello World

搭建最简单的一个web应用

### 下载源代码
* git clone 最新的代码

### 编译
* 切换到项目的目录，然后运行ant

### 运行
* 编译后产生run文件，然后运行 <br>
windows: run <br>
linux: ./run debug <br>
mac: ./run debug <br>

### 浏览器访问
* 浏览器访问 http://localhost:8080/hello-world.jsp

### 修改jsp文件
* 修改 web/hello-world.jsp 文件，得到你想要的效果
